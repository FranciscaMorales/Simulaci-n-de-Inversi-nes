# Nexum — Proyecto final (versión auditada)

Grupo 11 · ESF 2026-2. Proyecto reconstruido desde cero a partir de la auditoría del modelo anterior
(`~/Desktop/Modelo_Final_Nexum`, que se conserva como referencia histórica).

## Entregables
| Archivo | Qué es |
|---|---|
| `informe/Informe_Final_Nexum.docx` | Informe IPS + Estrategia (base del informe final y de la defensa) |
| `modelo/Modelo_Nexum_v2.xlsx` | Modelo en Excel: fórmulas vivas (TIR, covarianzas, Black-Litterman), recalculado, 0 errores |
| `resultados/resultados_modelo.xlsx` | Todas las tablas de resultados |
| `informe/figuras/` | Gráficos del informe |

## Código (`codigo/`)
| Módulo | Contenido |
|---|---|
| `config.py` | Todos los parámetros (fuente única de verdad) |
| `datos.py` | Carga de datos (caché en `datos/`) |
| `estrategias.py` | Backtests point-in-time: Momentum, Low-Volatility, Momentum en commodities |
| `portafolio.py` | Markowitz, Black-Litterman, benchmark y métricas |
| `objetivos.py` | Flujos, TIR requerida, factibilidad, plan de desembolsos |
| `montecarlo.py` | Montecarlo en USD y UF, histórico y prospectivo |
| `validacion.py` | Robustez de parámetros y walk-forward |
| `run_all.py` | Corre todo y guarda `resultados/` (≈10 min; la robustez queda en caché) |
| `excel_modelo.py`, `figuras.py`, `informe.py` | Generan el Excel, los gráficos y el informe |
| `senales.py` | Señales de operación con precios del día (uso semanal/mensual) |

Orden: `python3 run_all.py && python3 excel_modelo.py && python3 figuras.py && python3 informe.py`.
El Excel debe abrirse y guardarse en Microsoft Excel una vez para que queden visibles los valores de las fórmulas.

## Correcciones respecto del modelo anterior
1. Se eliminaron los dos meses de 2018 que el modelo descartaba por un dato vacío de Low-Vol (162 → 164 meses).
2. El filtro de Sharpe de Momentum usa volatilidad de 12 meses (igual que en la operación real).
3. Black-Litterman calculado con fórmulas en el Excel (antes: columna π desplazada y valores pegados).
4. Benchmark único e invertible por sleeve (Low-Vol contra SPLV, Momentum contra QMOM).
5. Se eliminaron hojas y textos de la arquitectura anterior (calce LDI) y las referencias a Betting Against Beta.
6. Sesgo de selección del universo de commodities declarado y controlado.
La versión portada reproduce exactamente el modelo anterior antes de aplicar las correcciones (diferencia 10⁻¹⁶).
Los pesos aprobados se mantienen: recalibrados, difieren menos de 0,7 puntos.

## Pendiente para el grupo
- Aplicar el cuestionario de tolerancia al riesgo a los clientes (no simularlo).
- Actualizar la sección 5 del informe (implementación) con los resultados al cierre de la simulación.
- Convertir el informe en la presentación de 20 minutos.
